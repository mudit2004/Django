# Used by the ErrorHandlerResolutionTests test case.

from .views import empty_view

urlpatterns = []

handler400 = empty_view
handler404 = empty_view
handler500 = empty_view
